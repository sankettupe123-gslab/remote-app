from django.shortcuts import render
import time

# Create your views here.


from django.http import HttpResponse
from django.shortcuts import render_to_response

def hello(request):
   text = """<h1>welcome to my app !</h1>"""
   return HttpResponse(text)

import winrm


def index(request):
    """

    :param request: no param
    :return: index.html and output of command
    """
    #return render_to_response('templates/index.html')
    s = winrm.Session('10.136.60.90', auth=('administrator', '$@NKET9822'))
    allservices = "ipconfig"
    r = s.run_ps(allservices)
    r.status_code
    print "------- All Services ----- "
    op = r.std_out

    #return render(request, "index.html")
    return render(request, "index.html", {"op" : op})


from WinRemote.models import history
from django.utils import timezone
def usercmd(request):
    """

    :param request: ip,user,password,command
    :return: op.html, ip , output, command, statuscode
    """
    ipin = request.POST['ip']
    user = request.POST['user']
    passw = request.POST['pass']
    cmd = request.POST['cmd']
    #s = winrm.Session('10.136.60.90', auth=('administrator', '$@NKET9822'))
    s = winrm.Session(ipin, auth=(user,passw))
    r = s.run_ps(cmd)
    r.status_code
    op = r.std_out

    b = history(command=cmd,output=op,ip=ipin,time=timezone.now())
    b.save()
    return render(request, 'op.html', {"ip": ipin,"output": op,"cmd": cmd,"statuscode":r.status_code})


def optools(request):
    """

    :param request: ip,user,pass,input
    :return: op html , ip,output,cmd,statuscode
    """
    ipin = request.POST['ip']
    user = request.POST['user']
    passw = request.POST['pass']
    cmd = request.POST.get('input')
    #s = winrm.Session('10.136.60.90', auth=('administrator', '$@NKET9822'))
    s = winrm.Session(ipin, auth=(user,passw))
    r = s.run_ps(cmd)
    r.status_code
    op = r.std_out
    b = history(command=cmd,output=op,ip=ipin,time=timezone.now())
    b.save()
    return render(request, 'op.html', {"ip": ipin,"output": op,"cmd": cmd,"statuscode":r.status_code})


def runapps(request):
    """

    :param request: ip,user,pass,service start/stop, command
    :return: ip,output,command,statuscode.
    """
    ipin = request.POST['ip']
    user = request.POST['user']
    passw = request.POST['pass']
    serv = request.POST.get('serv')
    cmd =  request.POST['cmd']
    cmd = serv + " " + cmd
     # s = winrm.Session('10.136.60.90', auth=('administrator', '$@NKET9822'))
    s = winrm.Session(ipin, auth=(user, passw))
    r = s.run_ps(cmd)
    r.status_code
    op = r.std_out
    b = history(command=cmd, output=op, ip=ipin, time=timezone.now())
    b.save()
    return render(request, 'op.html', {"ip": ipin,"output": op, "cmd": cmd, "statuscode": r.status_code})


def iapp(request):
    """

    :param request:
    :return:
    """
    return render(request, 'startapp.html')


def itools(request):
    return render(request, 'tools.html')


def historycmd(request):
    """

    :param request:
    :return:
    """
    all_entries = history.objects.all();
    return render(request, 'history.html',{"obj": all_entries})