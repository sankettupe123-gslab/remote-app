
from django.conf.urls import url, include
from . import views

urlpatterns = [
url(r'^hello/',views.hello, name='hello' ),
url(r'^usercmd/',views.usercmd, name='usercmd' ),
url(r'^$', views.index, name='index'),
url(r'^history/',views.historycmd, name='historycmd'),
url(r'^tool/',views.itools, name='itools'),
url(r'^tools/',views.optools, name='optools'),
url(r'^startapp/',views.iapp, name='iapp'),
url(r'^runapp/',views.runapps, name='runapps'),
]


